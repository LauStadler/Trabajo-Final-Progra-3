package models;

public class ContrasenaIncorrectaException extends Exception {

    public ContrasenaIncorrectaException(String arg){
        super(arg);
    }

}
