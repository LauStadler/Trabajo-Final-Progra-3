package models;

public class UsuarioYaExistenteException extends Exception {

    public UsuarioYaExistenteException(String arg){
        super(arg);
    }
    
}
