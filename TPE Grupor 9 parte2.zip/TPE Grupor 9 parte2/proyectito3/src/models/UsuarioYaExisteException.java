package models;

public class UsuarioYaExisteException {

}
