package models;

@SuppressWarnings("serial")
public class ViajeNoPosibleException extends Exception{


	public ViajeNoPosibleException(String argumento){
        super(argumento);
    }
    
    

}