package models;

public class PedidoInvalidoException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public PedidoInvalidoException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public PedidoInvalidoException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
