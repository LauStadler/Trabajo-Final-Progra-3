module TP_Grupo09 {
	exports models;
	exports util;
	exports controlador;
	exports prueba;
	exports vista;

	requires java.desktop;
	requires java.xml;
}