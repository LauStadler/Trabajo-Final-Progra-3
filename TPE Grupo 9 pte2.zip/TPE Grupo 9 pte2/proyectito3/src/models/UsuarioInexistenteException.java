package models;

public class UsuarioInexistenteException extends Exception {

    public UsuarioInexistenteException(String arg){
        super(arg);
    }

}
