package models;

import java.util.GregorianCalendar;

public class DecoradorSinBaul extends DecoratorBaul{
	

	public DecoradorSinBaul(IViaje encapsulado) {
		super(encapsulado);
		// TODO Auto-generated constructor stub
	}
	
}