package models;

public class ZonaInvalidaException extends Exception implements Cloneable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4527343055299595581L;

	public ZonaInvalidaException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ZonaInvalidaException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
	
}
