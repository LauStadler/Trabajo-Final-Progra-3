package models;

import java.io.Serializable;

public class ClienteDTO implements Serializable{
	private String usuario;
	private String contrasenia;
	
	public ClienteDTO() {
		// TODO Auto-generated constructor stub
	}

	public String getUsuario() {
		return usuario;
	}

	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}

	public String getContrasenia() {
		return contrasenia;
	}

	public void setContrasenia(String contrasenia) {
		this.contrasenia = contrasenia;
	}
	
	
}
