package models;

import java.util.GregorianCalendar;

public class DecoradorSinMascota extends DecoratorMascota{

	public DecoradorSinMascota(IViaje encapsulado) {
		super(encapsulado);
		// TODO Auto-generated constructor stub
	}
	
}

