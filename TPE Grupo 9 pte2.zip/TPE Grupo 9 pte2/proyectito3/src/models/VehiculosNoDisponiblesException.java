package models;

public class VehiculosNoDisponiblesException extends ViajeNoPosibleException{

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public VehiculosNoDisponiblesException(String argumento){
        super(argumento);
    }
}
